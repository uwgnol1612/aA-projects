require 'test_helper'

class SubpostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
