class PostsController < ApplicationController
  before_action :loggin_required, except: [:show]

  def new
    @post = Post.new 
  end

  def edit
    @post = Post.find(params[:id])
  end

  def show
    @post = Post.find(params[:id])
  end

  def update
    @post = Post.find(params[:id])

    if @post && @post.author_id = current_user.id 
      @post.update_attributes!(post_params)
      redirect_to post_url(@post)
    elsif !!@post
      flash.now[:errors] = "post dose not exist"
      render :edit
    else  
      flash.now[:errors] = "you are not allowed to edit this"
      render :edit
    end

  end

  def destroy
    @post = Post.find(params[:id])
    @post.destroy 
    redirect_to sub_url(@post.sub)
  end

  def create
    @post = Post.new(post_params)
    @post.author_id = current_user.id 

    if @post.save
      redirect_to post_url(@post)
    else
      flash.now[:errors] = @post.errors.full_messages
      render :new 
    end  
  end

  def post_params
    params.require(:post).permit(:title, :url, :content, :sub_ids[])
  end 
end
